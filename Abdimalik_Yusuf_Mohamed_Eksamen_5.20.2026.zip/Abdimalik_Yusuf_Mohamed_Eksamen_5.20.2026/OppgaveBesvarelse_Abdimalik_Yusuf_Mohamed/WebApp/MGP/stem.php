<?php
require 'db.php';
session_start();

$melding = "";

// Hent alle land
$land = $conn->query("SELECT * FROM land");

// Når bruker stemmer
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ip = $_SERVER["REMOTE_ADDR"];
    $landID = $_POST["landID"];
    $aarID = 1; // 2026

    // Sjekk om IP allerede har stemt
    $sjekk = $conn->prepare("SELECT COUNT(*) as antall FROM bruker b 
        JOIN stemme s ON b.BrukerID = s.BrukerID 
        WHERE b.IPAdresse = ? AND s.AarID = ?");
    $sjekk->bind_param("si", $ip, $aarID);
    $sjekk->execute();
    $resultat = $sjekk->get_result()->fetch_assoc();

    if ($resultat["antall"] > 0) {
        $melding = "Du har allerede stemt i år!";
    } else {
        // Lagre bruker
        $lagreBruker = $conn->prepare("INSERT INTO bruker (IPAdresse) VALUES (?)");
        $lagreBruker->bind_param("s", $ip);
        $lagreBruker->execute();
        $brukerID = $conn->insert_id;

        // Lagre stemme
        $lagreStemme = $conn->prepare("INSERT INTO stemme (BrukerID, LandID, AarID) VALUES (?, ?, ?)");
        $lagreStemme->bind_param("iii", $brukerID, $landID, $aarID);
        $lagreStemme->execute();

        $melding = "Takk for din stemme!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>MGP Stemming</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Stem på MGP 2026</h1>

        <?php if ($melding): ?>
            <p><?= $melding ?></p>
        <?php endif; ?>

        <form method="post">
            <label>Velg land:</label>
                <select name="landID">
                    <?php while ($row = $land->fetch_assoc()): ?>
                        <option value="<?= $row["LandID"] ?>"><?= $row["LandNavn"] ?></option>
                    <?php endwhile; ?>
                </select>
                <br><br>
            <button type="submit">Stem!</button>
        </form>
    </div>
</body>
</html>