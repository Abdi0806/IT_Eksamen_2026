<?php
$host = "localhost";
$bruker = "root";
$passord = "";
$database = "mgp";

$conn = new mysqli($host, $bruker, $passord, $database);

if ($conn->connect_error) {
    die("Tilkobling feilet: " . $conn->connect_error);
}
?>