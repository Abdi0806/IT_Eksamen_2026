<?php
require 'db.php';

$antall = 1000; // Antall stemmer som skal legges inn
$antallLand = 10; // Vi har 10 land
$antallAar = 3; // Vi har 3 år (AarID 1, 2, 3)

for ($i = 0; $i < $antall; $i++) {
    // Tilfeldig IP
    $ip = rand(1,255) . "." . rand(1,255) . "." . rand(1,255) . "." . rand(1,255);
    
    // Tilfeldig land og år
    $landID = rand(1, $antallLand);
    $aarID = rand(1, $antallAar);

    // Lagre bruker
    $lagreBruker = $conn->prepare("INSERT INTO bruker (IPAdresse) VALUES (?)");
    $lagreBruker->bind_param("s", $ip);
    $lagreBruker->execute();
    $brukerID = $conn->insert_id;

    // Lagre stemme
    $lagreStemme = $conn->prepare("INSERT INTO stemme (BrukerID, LandID, AarID) VALUES (?, ?, ?)");
    $lagreStemme->bind_param("iii", $brukerID, $landID, $aarID);
    $lagreStemme->execute();
}

echo "Ferdig! $antall tilfeldige stemmer er lagt inn.";
?>